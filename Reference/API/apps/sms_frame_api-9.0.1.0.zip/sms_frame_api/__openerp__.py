{
    'name': "SMS Framework - REST API",
    'version': "1.0",
    'author': "Sythil Tech",
    'category': "Tools",
    'summary':'Extends the sms framework giving it api access',
    'description':'Extends the sms framework giving it api access',    
    'license':'LGPL-3',
    'data': [
        'views/res_users_views.xml',
    ],
    'demo': [],
    'depends': ['sms_frame'],
    'images':[
        'static/description/1.jpg',
    ],
    'installable': True,
}