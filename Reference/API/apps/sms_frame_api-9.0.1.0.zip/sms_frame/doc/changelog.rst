v1.0.9
======
* Fix queue sms check issue

v1.0.8
======
* SMS queuing in position for mass sms

v1.0.7
======
* MMS template sending fix

v1.0.6
======
* MMS templates

v1.0.5
======
* MMS framework

v1.0.4
======
* Fix template send sms code

v1.0.3
======
* Make it easier to have 2 way conversations via sms

v1.0.2
======
* Fix major bug which mapped received messages to the wrong partner

v1.0
====
* Initial release